﻿var app = angular.module('myApp', []);

app.controller('searchCtrl', ['$scope', '$http', function searchCtrl($scope, $http) {
    $scope.search = function () {
        $http.get('https://api.github.com/search/repositories?q=' + $scope.searchCondition)
            .then(function (res) {
                if (!res.data)
                    return;
                //set the data on scope
                $scope.array = res.data.items;
            });
    }

    $scope.save = function (item) {
        var obj = {
            repositoryName: item.name,
            img: item.owner.avatar_url,
            id:item.id
        }
        //sending server changed item: checked or unchecked
        $http.post('/home/save', { obj: obj, isChecked: item.isChecked });
            
    }

}]);
