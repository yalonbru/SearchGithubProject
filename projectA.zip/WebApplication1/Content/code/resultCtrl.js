﻿var app = angular.module('myApp', []);

app.controller('resultCtrl', ['$scope', '$http', function resultCtrl($scope, $http) {
        $http.get('/home/getCheckedItems')
            .then(function (res) {
                if (!res.data)
                    return;
                
                $scope.array = res.data;
            });


}]);
