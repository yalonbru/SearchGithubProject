﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Results()
        {
            return View();
        }
        public ActionResult Save(DTO obj, bool isChecked)
        {
            //get data from session on temp variable
            var temp = HttpContext.Session["items"] as List<DTO>;
            
            if(temp == null)
            {
                temp = new List<DTO>();
            }
            //update values session: remove or add
            if (!isChecked)
            {
                temp.Remove(temp.FirstOrDefault(x => x.Id == obj.Id));
            }
            else
            {
                temp.Add(obj);
            }
            Session["items"] = temp;

            return Json(temp.Count, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetCheckedItems()
        {
            //convert before sending to client
            var res = HttpContext.Session["items"] as List<DTO>;
            return Json(res, JsonRequestBehavior.AllowGet);
        }

        public class DTO
        {
            public string RepositoryName { get; set; }
            public string Img { get; set; }
            public int Id { get; set; }
        }
    }
}